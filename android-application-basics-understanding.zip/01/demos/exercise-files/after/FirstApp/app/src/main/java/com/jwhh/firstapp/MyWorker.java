package com.jwhh.firstapp;

public class MyWorker {
    public static int doubleTheValue(int value){
        return value * 2;
    }
}
